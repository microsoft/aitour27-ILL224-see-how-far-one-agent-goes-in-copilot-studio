#!/usr/bin/env python3
"""Calculate supplier invoice exceptions with decimal-safe arithmetic."""

import argparse
import json
import re
import textwrap
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from typing import Any


CURRENCY = Decimal("0.01")
HUMAN_REVIEW_THRESHOLD = Decimal("10000.00")


def money(value: Any) -> Decimal:
    return Decimal(str(value)).quantize(CURRENCY, rounding=ROUND_HALF_UP)


def display(value: Decimal) -> str:
    return format(value, ".2f")


def recommendation(disputed: Decimal, reconciliation: Decimal, payload: dict[str, Any]) -> str:
    if (
        payload.get("missingEvidence")
        or payload.get("conflictingEvidence")
        or payload.get("policyUnclear")
        or reconciliation != Decimal("0.00")
    ):
        return "Hold for clarification"
    if disputed > Decimal("0.00"):
        return "Approve the supported amount and challenge the exception"
    return "Approve the supported amount"


def calculate(payload: dict[str, Any]) -> dict[str, Any]:
    invoice_total = money(payload["invoiceTotal"])
    line_results = []
    total_disputed = Decimal("0.00")
    total_undisputed = Decimal("0.00")

    for line in payload["lineItems"]:
        invoiced = money(line["invoicedAmount"])
        permitted = money(line["contractPermittedAmount"])
        undisputed = min(max(permitted, Decimal("0.00")), invoiced)
        disputed = invoiced - undisputed
        total_disputed += disputed
        total_undisputed += undisputed
        line_results.append(
            {
                "description": line["description"],
                "invoicedAmount": display(invoiced),
                "contractPermittedAmount": display(permitted),
                "disputedAmount": display(disputed),
                "undisputedAmount": display(undisputed),
            }
        )

    reconciliation = invoice_total - total_disputed - total_undisputed
    review_reasons = []
    if total_disputed > HUMAN_REVIEW_THRESHOLD:
        review_reasons.append("disputed amount exceeds $10,000")
    if payload.get("missingEvidence"):
        review_reasons.append("required evidence is missing or stale")
    if payload.get("conflictingEvidence"):
        review_reasons.append("required evidence is conflicting")
    if payload.get("activeQualityHold"):
        review_reasons.append("an active quality hold exists")
    if payload.get("policyUnclear"):
        review_reasons.append("policy does not clearly cover the case")
    if reconciliation != Decimal("0.00"):
        review_reasons.append("invoice arithmetic does not reconcile")

    return {
        "supplierName": payload["supplierName"],
        "invoiceId": payload["invoiceId"],
        "purchaseOrder": payload["purchaseOrder"],
        "invoiceTotal": display(invoice_total),
        "lineResults": line_results,
        "disputedAmount": display(total_disputed),
        "undisputedAmount": display(total_undisputed),
        "reconciliationDifference": display(reconciliation),
        "recommendation": recommendation(total_disputed, reconciliation, payload),
        "requiresHumanReview": bool(review_reasons),
        "humanReviewReasons": review_reasons,
    }


def pdf_escape(value: str) -> str:
    return value.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def create_review_document(
    payload: dict[str, Any], result: dict[str, Any], output_dir: Path
) -> Path:
    safe_invoice_id = re.sub(r"[^A-Za-z0-9_-]", "_", str(result["invoiceId"]))
    output_path = output_dir / f"Caldova_Supplier_Review_{safe_invoice_id}.pdf"
    output_dir.mkdir(parents=True, exist_ok=True)

    reasons = result["humanReviewReasons"] or ["No policy condition requires human review"]
    citations = payload.get("evidenceCitations") or ["No citations supplied"]
    lines = [
        "CALDOVA PHARMACEUTICALS | SUPPLIER ASSURANCE",
        f"Supplier review: {result['invoiceId']}",
        "",
        f"Supplier: {result['supplierName']}",
        f"Purchase order: {result['purchaseOrder']}",
        "",
        "RECOMMENDATION",
        result["recommendation"],
        f"Human review required: {'Yes' if result['requiresHumanReview'] else 'No'}",
        "",
        "FINANCIAL SUMMARY",
        f"Invoice total: ${result['invoiceTotal']}",
        f"Undisputed amount: ${result['undisputedAmount']}",
        f"Disputed amount: ${result['disputedAmount']}",
        f"Reconciliation difference: ${result['reconciliationDifference']}",
        "",
        "LINE ANALYSIS",
    ]
    for line in result["lineResults"]:
        lines.append(
            f"{line['description']}: invoiced ${line['invoicedAmount']}; "
            f"supported ${line['contractPermittedAmount']}; disputed ${line['disputedAmount']}"
        )
    lines.extend(["", "HUMAN REVIEW REASONS"])
    lines.extend(f"- {reason}" for reason in reasons)
    lines.extend(["", "EVIDENCE SUMMARY", str(payload.get("evidenceSummary", "See citations."))])
    lines.extend(["", "EVIDENCE CITATIONS"])
    lines.extend(f"- {citation}" for citation in citations)
    lines.extend(
        [
            "",
            "This document is a recommendation. It does not execute payment, reject an invoice,",
            "or change supplier status.",
        ]
    )

    wrapped_lines = []
    for line in lines:
        wrapped_lines.extend(textwrap.wrap(str(line), width=88) or [""])

    pages = [wrapped_lines[index : index + 52] for index in range(0, len(wrapped_lines), 52)]
    font_object_number = 3 + (2 * len(pages))
    page_object_numbers = [3 + (2 * index) for index in range(len(pages))]
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        (
            f"<< /Type /Pages /Kids [{' '.join(f'{number} 0 R' for number in page_object_numbers)}] "
            f"/Count {len(pages)} >>"
        ).encode(),
    ]
    for index, page_lines in enumerate(pages):
        page_object_number = page_object_numbers[index]
        content_object_number = page_object_number + 1
        commands = ["BT", "/F1 10 Tf", "50 750 Td", "13 TL"]
        for line_index, line in enumerate(page_lines):
            if line_index:
                commands.append("T*")
            commands.append(f"({pdf_escape(line)}) Tj")
        commands.append("ET")
        stream = "\n".join(commands).encode("latin-1", errors="replace")
        objects.extend(
            [
                (
                    f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
                    f"/Resources << /Font << /F1 {font_object_number} 0 R >> >> "
                    f"/Contents {content_object_number} 0 R >>"
                ).encode(),
                b"<< /Length "
                + str(len(stream)).encode()
                + b" >>\nstream\n"
                + stream
                + b"\nendstream",
            ]
        )
    objects.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
    pdf = bytearray(b"%PDF-1.4\n")
    offsets = [0]
    for object_number, obj in enumerate(objects, start=1):
        offsets.append(len(pdf))
        pdf.extend(f"{object_number} 0 obj\n".encode())
        pdf.extend(obj)
        pdf.extend(b"\nendobj\n")
    xref_offset = len(pdf)
    pdf.extend(f"xref\n0 {len(objects) + 1}\n".encode())
    pdf.extend(b"0000000000 65535 f \n")
    for offset in offsets[1:]:
        pdf.extend(f"{offset:010d} 00000 n \n".encode())
    pdf.extend(
        f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\nstartxref\n{xref_offset}\n%%EOF\n".encode()
    )
    output_path.write_bytes(pdf)
    return output_path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--input-file", type=Path)
    source.add_argument("--input-json")
    parser.add_argument("--output-dir", type=Path, default=Path("."))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.input_file:
        payload = json.loads(args.input_file.read_text(encoding="utf-8"))
    else:
        payload = json.loads(args.input_json)
    result = calculate(payload)
    review_document = create_review_document(payload, result, args.output_dir)
    result["reviewDocument"] = str(review_document)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()