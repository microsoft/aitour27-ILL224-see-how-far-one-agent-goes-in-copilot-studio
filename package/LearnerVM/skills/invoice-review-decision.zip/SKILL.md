---
name: supplier-policy-triage
description: Use after evidence has been gathered for a supplier invoice exception. Consume the cited evidence packet, run packaged Python to calculate supported and disputed amounts, apply Caldova review rules, and create a shareable PDF decision brief.
---

# Supplier Policy Triage

Triage a supplier exception from the cited evidence packet produced by Supplier Evidence Gathering. This skill owns calculation and policy analysis; it does not search for evidence.

## Procedure

1. Confirm that the evidence packet identifies the supplier, invoice, purchase order, invoice total, every invoice line, governing contract terms, supplier status, quality status, missing or conflicting evidence, and source citations. If required fields are absent, identify what is missing and request a completed evidence packet.
2. Compare each charge with its cited contract term and any written approval. Never treat an uncited statement as approval, and distinguish an open quality investigation from an active quality hold.
3. Build one JSON input for `calculate_supplier_review.py` using only values supported by the evidence packet:
   - `supplierName`, `invoiceId`, `purchaseOrder`, and `invoiceTotal`
   - `lineItems`, with `description`, `invoicedAmount`, and `contractPermittedAmount` for every invoice line
   - `missingEvidence`, `conflictingEvidence`, `activeQualityHold`, and `policyUnclear` as Boolean values
   - `evidenceSummary` and `evidenceCitations` from the evidence packet
4. You MUST use the available code-execution tool to execute the packaged root-level Python file. Do not calculate the values yourself and do not answer before the command finishes. Run this command, replacing `<JSON>` with the single-line JSON input:

   ```bash
   python calculate_supplier_review.py --input-json '<JSON>'
   ```

5. If no code-execution tool is available or the command fails, stop and return `PYTHON_EXECUTION_FAILED` followed by the tool error. Never substitute prose arithmetic.
6. Treat the script output as the only source for line-level amounts, totals, reconciliation, recommendation, human-review triggers, and `reviewDocument` path.
7. Return the generated `Caldova_Supplier_Review_<invoiceId>.pdf` file to the user as a downloadable artifact.
8. Separately state whether human review is required and list every reason returned by the script. Do not conceal missing, stale, conflicting, or ambiguous evidence.

## Response

Return these dynamic fields from the current evidence packet and script result:

- `supplierName`
- `invoiceId`
- `purchaseOrder`
- `invoiceTotal`
- `disputedAmount`
- `undisputedAmount`
- `reconciliationDifference`
- `recommendation`
- `policyChecks`
- `evidenceSummary`
- `requiresHumanReview`
- `humanReviewReason`
- `reviewDocument`

Present readable sections for Recommendation, Financial summary, Policy checks, Exceptions found, Evidence citations, Missing or conflicting evidence, Human review required, and Human review reason.

Never execute payment, reject an invoice, or change supplier status.